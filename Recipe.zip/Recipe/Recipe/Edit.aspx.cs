﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.ComponentModel;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;

namespace Recipe
{
    public partial class Edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            try
            {
                if (!IsPostBack)
                {
                    int id = Convert.ToInt16(Request["id"]);
                    RecipeServiceReference.RecipeServiceClient client = new RecipeServiceReference.RecipeServiceClient();
                    Recipe.RecipeServiceReference.Recipe rec = new Recipe.RecipeServiceReference.Recipe();
                    rec = client.GetSpecificRecipe(id);
                    DataTable dt = new DataTable();
                    dt = rec.RecipeTable;


                    lblTitle.Text = dt.Rows[0]["recipe_title"].ToString();

                    txtIngredients.Text = dt.Rows[0]["ingredients"].ToString();

                    if (Convert.ToInt16(dt.Rows[0]["levels"]) > 0)
                    {
                        int value = Convert.ToInt16(dt.Rows[0]["levels"]);
                        var enumDisplayStatus = (Levels)value;
                        string stringValue = enumDisplayStatus.ToString();

                        txtLevel.Text = enumDisplayStatus.ToString();

                    }
                    txtSteps.Text = dt.Rows[0]["steps"].ToString();
                    HiddenField1.Value = Convert.ToString(id);

                    if (!string.IsNullOrEmpty(dt.Rows[0]["image1"].ToString()))
                        txtLevelImg.Src = String.Format("data:image/Bmp;base64,{0}\"", GetImage(dt.Rows[0]["image1"]));


                    if (!string.IsNullOrEmpty(dt.Rows[0]["image2"].ToString()))
                        txtIngredientsImg.Src = String.Format("data:image/Bmp;base64,{0}\"", GetImage(dt.Rows[0]["image2"]));



                    if (!string.IsNullOrEmpty(dt.Rows[0]["image3"].ToString()))
                        txtStepsImg.Src = String.Format("data:image/Bmp;base64,{0}\"", GetImage(dt.Rows[0]["image3"]));
                }
            }
            catch (Exception ex)
            {

            }
        }


        private string GetImage(object objImage)
        {
            byte[] imgBytes = (byte[])objImage;
            try
            {
                TypeConverter tc = TypeDescriptor.GetConverter(typeof(Bitmap));
                Bitmap MyBitmap = (Bitmap)tc.ConvertFrom(imgBytes);

            }
            catch (Exception ex)
            {

            }

            return Convert.ToBase64String(imgBytes);
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                RecipeServiceReference.RecipeServiceClient client = new RecipeServiceReference.RecipeServiceClient();
                int isSuccess = client.UpdateRecipe(Convert.ToInt16(HiddenField1.Value), lblTitle.Text, txtIngredients.Text, txtSteps.Text);


                //lblSuccess.Text = (isSuccess > 0) ? "Success" : "Failure";

                if (isSuccess > 0)
                {

                    Recipe.RecipeServiceReference.Recipe rec = new Recipe.RecipeServiceReference.Recipe();
                    rec = client.GetSpecificRecipe(Convert.ToInt16(HiddenField1.Value));
                    DataTable dt = new DataTable();
                    dt = rec.RecipeTable;

                    txtIngredients.Text = dt.Rows[0]["ingredients"].ToString();
                    txtSteps.Text = dt.Rows[0]["steps"].ToString();
                    HiddenField1.Value = HiddenField1.Value;
                }

            }
            catch (Exception ex)
            {

            }


        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            string attachment = "attachment; filename=" + "abc" + ".pdf";
            Response.ClearContent();
            Response.AddHeader("content-disposition", attachment);
            Response.ContentType = "application/pdf";
            StringWriter s_tw = new StringWriter();
            HtmlTextWriter h_textw = new HtmlTextWriter(s_tw);
            h_textw.AddStyleAttribute("font-size", "7pt");
            h_textw.AddStyleAttribute("color", "Black");
            Panel1.RenderControl(h_textw);//Name of the Panel
            Document doc = new Document();
            doc = new Document(PageSize.A4, 5, 5, 15, 5);
            FontFactory.GetFont("Verdana", 80, iTextSharp.text.BaseColor.RED);
            PdfWriter.GetInstance(doc, Response.OutputStream);
            doc.Open();
            StringReader s_tr = new StringReader(s_tw.ToString());
            HTMLWorker html_worker = new HTMLWorker(doc);
            html_worker.Parse(s_tr);
            doc.Close();
            Response.Write(doc);



        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {

        }

        public override void VerifyRenderingInServerForm(Control control)
        {

        }

        public enum Levels
        {
            Easy = 0,
            Intermediate = 1,
            Hard = 2

        }



    }
}