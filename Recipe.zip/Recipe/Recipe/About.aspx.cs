﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Recipe.RecipeServiceReference;
using System.Data;
using System.IO;

namespace Recipe
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {     
       
            
            btnManage.Enabled = true;
            idManage.Visible = false;
            btnCreate.Enabled = false;
            idCreate.Visible = true;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            try
            {
                RecipeServiceReference.RecipeServiceClient client = new RecipeServiceReference.RecipeServiceClient();

                if (string.IsNullOrEmpty(txtRecipe.Text))
                    return;

                if (string.IsNullOrEmpty(txtIngredients.Text))
                    return;

                if (string.IsNullOrEmpty(txtSteps.Text))
                    return;

                if (string.IsNullOrEmpty(ddlLevel.SelectedValue))
                    return;


                HttpPostedFile postedFile = FileUpload1.PostedFile;
                string filename = Path.GetFileName(postedFile.FileName);
                string fileExtension = Path.GetExtension(filename);


                postedFile = FileUpload2.PostedFile;
                string filename2 = Path.GetFileName(postedFile.FileName);
                string fileExtension2 = Path.GetExtension(filename2);


                postedFile = FileUpload3.PostedFile;
                string filename3 = Path.GetFileName(postedFile.FileName);
                string fileExtension3 = Path.GetExtension(filename3);



                //if (fileExtension.ToLower().Contains(".jpg, .gif, .png, .bmp") || fileExtension2.ToLower().Contains(".jpg, .gif, .png, .bmp") || fileExtension3.ToLower().Contains(".jpg, .gif, .png, .bmp"))
                //{
                Stream stream = postedFile.InputStream;
                BinaryReader binaryReader = new BinaryReader(stream);
                Byte[] bytes = binaryReader.ReadBytes((int)stream.Length);

                stream = postedFile.InputStream;
                binaryReader = new BinaryReader(stream);
                Byte[] bytes2 = binaryReader.ReadBytes((int)stream.Length);

                stream = postedFile.InputStream;
                binaryReader = new BinaryReader(stream);
                Byte[] byte3 = binaryReader.ReadBytes((int)stream.Length);



                int iten = client.InsertRecipe(txtRecipe.Text, txtIngredients.Text, txtSteps.Text, ddlLevel.SelectedValue, bytes, bytes2, byte3);

                //}


                BindGrid();

                btnManage.Enabled = false;
                btnCreate.Enabled = true;
                idManage.Visible = true;
                idCreate.Visible = false;

            }
            catch (Exception ex)
            {

            }
        }

        private void BindGrid()
        {
            try
            {
                RecipeServiceClient client = new RecipeServiceReference.RecipeServiceClient();
                Recipe.RecipeServiceReference.Recipe rec = new Recipe.RecipeServiceReference.Recipe();
                rec = client.GetRecipe();
                DataTable dt = new DataTable();
                dt = rec.RecipeTable;

                GridView1.DataSource = dt;
                GridView1.DataBind();

            }
            catch (Exception ex)
            {

            }
        }

        protected void btnManage_Click(object sender, EventArgs e)
        {
            btnManage.Enabled = false;
            btnCreate.Enabled = true;
            idManage.Visible = true;
            idCreate.Visible = false;
            BindGrid();
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            btnManage.Enabled = true;
            btnCreate.Enabled = false;
            idManage.Visible = false;
            idCreate.Visible = true;

        }


        [System.Web.Services.WebMethod]
        public static string AddTextbox(int id)
        {
            id = id + 1;

            return "<br/> <tr id='idIng' + '" + id + "'><td><input type='text' id='txtIngredients' + '" + id + "'" + "runat='server'></td><td>"
                   + "<img class='idAdd' alt='upload' src='Scripts/upload.png' width='10px' />" +
             "   </td></tr>";

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditRow")
                {
                    int rowIndex = ((GridViewRow)((ImageButton)e.CommandSource).NamingContainer).RowIndex;

                    int Id = Convert.ToInt32(e.CommandArgument);

                    Response.Redirect("Edit.aspx?id=" + Id);

                }

            }
            catch (Exception ex)
            {

            }
        }       


    }
}
