﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace RecipeService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "RecipeService" in code, svc and config file together.
    public class RecipeService : IRecipeService
    {
        public void DoWork()
        {
        }

        public string GetMessage(string str)
        {
            return "Hello" + str;
        }

        public Recipe GetSpecificRecipe(int id)
        {
            string strConnectionString = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            SqlConnection con = new SqlConnection(strConnectionString);
            SqlDataAdapter adp = new SqlDataAdapter("select * from Recipe where recipe_id = '" + id + "'", con);

            DataSet ds = new DataSet();
            adp.Fill(ds);

            Recipe r = new Recipe();
            r.RecipeTable = ds.Tables[0];
            return r;

        }

        public Recipe GetRecipe()
        {         
            string strConnectionString = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            SqlConnection con = new SqlConnection(strConnectionString);
            SqlDataAdapter adp = new SqlDataAdapter("select * from Recipe", con);

            DataSet ds = new DataSet();
            adp.Fill(ds);

            Recipe r = new Recipe();
            r.RecipeTable = ds.Tables[0];
            return r;

        }       

        public int InsertRecipe(string Title, string Ingredients, string Steps, string Levels, Byte[] img1, Byte[] img2, Byte[] img3)
        {
         
            string strConnectionString = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                string insert = "insert  into Recipe (recipe_title, image1, image2, image3, ingredients, steps, levels, created_date)" +
                                " values (@Title,  @img1, @img2, @img2, @ingredients, @Steps, @Levels, @CreateDate)";

                SqlCommand cmd = new SqlCommand(insert, con);
                SqlParameter paramTitle = new SqlParameter("@Title", Title);
                cmd.Parameters.Add(paramTitle);

                SqlParameter paramImage1 = new SqlParameter("@img1", img1);
                cmd.Parameters.Add(paramImage1);

                SqlParameter paramImage2 = new SqlParameter("@img2", img2);
                cmd.Parameters.Add(paramImage2);

                SqlParameter paramImage3 = new SqlParameter("@img3", img3);
                cmd.Parameters.Add(paramImage3);


                SqlParameter paramIngredients = new SqlParameter("@ingredients", Ingredients);
                cmd.Parameters.Add(paramIngredients);


                SqlParameter paramSteps = new SqlParameter("@Steps", Steps);
                cmd.Parameters.Add(paramSteps);

                SqlParameter paramLevels = new SqlParameter("@Levels", Levels);
                cmd.Parameters.Add(paramLevels);

                SqlParameter paramCreateDate = new SqlParameter("@CreateDate", DateTime.Now);
                cmd.Parameters.Add(paramCreateDate);

                con.Open();
                return cmd.ExecuteNonQuery();

            }
        }


        public int UpdateRecipe(int Id, string Title, string Ingredients, string Steps)
        {
            string CS = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                string updateQuery = "Update Recipe  SET recipe_title = @Title,  " +
                    "ingredients = @Ingredients, steps = @Steps WHERE recipe_id = @Id";
                SqlCommand cmd = new SqlCommand(updateQuery, con);
                SqlParameter paramId = new
                    SqlParameter("@Id", Id);
                cmd.Parameters.Add(paramId);


                SqlParameter paramName = new SqlParameter("@Title", Title);
                cmd.Parameters.Add(paramName);

                SqlParameter paramIngredients = new SqlParameter("@Ingredients", Ingredients);
                cmd.Parameters.Add(paramIngredients);

                SqlParameter paramSteps = new SqlParameter("@Steps", Steps);
                cmd.Parameters.Add(paramSteps);

                con.Open();
                return cmd.ExecuteNonQuery();
            }
        }




    }
}
