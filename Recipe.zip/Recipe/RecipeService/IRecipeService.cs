﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;

namespace RecipeService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRecipeService" in both code and config file together.
    [ServiceContract]
    public interface IRecipeService
    {
        [OperationContract]
        void DoWork();

        [OperationContract]
        string GetMessage(string str);

        [OperationContract]
        int InsertRecipe(string Title, string Ingredients, string Steps, string Levels, Byte[] img1, Byte[] img2, Byte[] img3);

        [OperationContract]
        Recipe GetRecipe();

        [OperationContract]
        int UpdateRecipe(int Id, string Title, string Ingredients, string Steps);

        [OperationContract]
        Recipe GetSpecificRecipe(int Id);
        
    }

    [DataContract]
    public class Recipe
    {

        public Recipe()
        {
            this.RecipeTable = new DataTable("Recipe");
        }

        [DataMember]
        public DataTable RecipeTable { get; set; }


    }

}
